/* 
Need help? : Contact
=============================
-----------------------------
	Adhikari Surya
	Frontend Web Developer
	Email: info@bootstrappage.com
-----------------------------
=============================
Introduction
============
Business ltd templates is highly professional and clean designed and Google friendly html5 and css3 code template. 
This is supported in all devices (such as desktop, iPad and iPhone) and compatible in most of the popular browser.
Nice Jquery animation is available in this templates.
This template is suitable for any kinds of business or organization portfolio.
Different resources and technologies has been implemented at the time of development.
This is very flexible design so it easy to extend for new features and pages.

All the themes from Bootswatch are supported by this template which is already included in the package.


Features:
=========

1. Available with 12 different themes in 20 Differnet patterns.
2. Each page has cool Jquary transition.
3. Clean and professional design.

Pages Includeds
===============

1. Coming soon page.
2. Home page.
2. contact us page.
3. About us page.
4. Services page.
	1.services detail page
5. Blog
	1. Blog detail page.
6. Contact us page.
7. Typography Page


Additional Credits:
==================
1. Twitter Bootstrap (Version 2.2.1)
2. http://bootswatch.com 
3. http://mywebsolution.info 
4. http://www.sxc.hu
5. http://www.google.com/webfonts
6. http://fortawesome.github.com/Font-Awesome
7. http://subtlepatterns.com
8. http://www.flickr.com
9. http://maps.google.com/

**************************************************************
===================
* PLEASE Email if more informations needed.
* if You provide me email address I will let you know about new updates.
=============================
-----------------------------
	Adhikari Surya
	Frontend Web Developer
	Email: adh.surya@gmail.com
-----------------------------
=============================