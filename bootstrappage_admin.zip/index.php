<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Free Delta Admin</title>
		<meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<link rel="stylesheet/less" type="text/css" href="themes/less/bootstrap.less">
		<script src="themes/js/less/less.js" type="text/javascript"></script>
		<link rel="stylesheet" href="themes/style/fullcalendar.css" />	

		<link rel="stylesheet" href="themes/style/delta.main.css" />
		<link rel="stylesheet" href="themes/style/delta.grey.css"/>
	</head>
	<body>
	<br>
	<div id="sidebar"> 
		<h1 id="logo"><a href="index.php">Free Admin</a></h1>  
		<a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
		<ul>
			<li class="active"><a href="index.php"><i class="icon icon-home"></i> <span>Dashboard</span></a></li>
			<li class="submenu">
				<a href="#"><i class="icon icon-th-list"></i> <span>Form elements</span> <span class="label">3</span></a>
				<ul>
					<li><a href="#">Common elements</a></li>
					<li><a href="#">Validation</a></li>
					<li><a href="#">Wizard</a></li>
				</ul>
			</li>
			<li><a href="#"><i class="icon icon-tint"></i> <span>Buttons &amp; icons</span></a></li>
			<li><a href="#"><i class="icon icon-pencil"></i> <span>Interface elements</span></a></li>
			<li><a href="#"><i class="icon icon-th"></i> <span>Tables</span></a></li>
			<li><a href="#"><i class="icon icon-th-list"></i> <span>Grid Layout</span></a></li>
			<li class="submenu">
				<a href="#"><i class="icon icon-file"></i> <span>Sample pages</span> <span class="label">4</span></a>
				<ul>
					<li><a href="#">Invoice</a></li>
					<li><a href="#">Support chat</a></li>
					<li><a href="#">Calendar</a></li>
					<li><a href="#">Gallery</a></li>
				</ul>
			</li>
			<li>
				<a href="#"><i class="icon icon-signal"></i> <span>Charts &amp; graphs</span></a>
			</li>
			<li>
				<a href="#"><i class="icon icon-inbox"></i> <span>Widgets</span></a>
			</li>
		</ul>
	</div>
	  <div id="mainBody">
			<h1>Dashboard
				<div class="pull-right">
				<a class="btn btn-large tip-bottom" title="Manage Files"><i class="icon-file"></i></a>
				<a class="btn btn-large tip-bottom" title="Manage Users"><i class="icon-user"></i></a>
				<a class="btn btn-large tip-bottom" title="Manage Comments" style="position:relative"><i class="icon-comment"></i>
				<span style="position:absolute; border-radius:12px; top:-23%; height:16px; width:16px" class="label label-important">5</span></a>
				<a class="btn btn-large tip-bottom" title="Manage Orders"><i class="icon-shopping-cart"></i></a>
				<a class="btn btn-large" title="" href="#"><i class="icon icon-user"></i> <span>Profile</span></a>
				<a class="btn btn-large" title="" href="#"><i class="icon icon-cog"></i> Settings</a>
				<a class="btn btn-large btn-danger" title="" href="#"><i class="icon-off"></i></a>
				</div>
			</h1>
		<div id="breadcrumb">
			<a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a>
			<a href="#" class="current">Dashboard</a>
		</div>
		<div class="container-fluid">
			<div class="row-fluid">
				<div class="span12 center" style="text-align: center;">					
					<ul class="stat-boxes">
						<li class="popover-visits">
							<div class="left peity_bar_good"><span>2,4,9,7,12,10,12</span>+10%</div>
							<div class="right">
								<strong>36094</strong>
								Visits
							</div>
						</li>
						<li class="popover-users">
							<div class="left peity_bar_neutral"><span>20,15,18,14,10,9,9,9</span>0%</div>
							<div class="right">
								<strong>1433</strong>
								Users
							</div>
						</li>
						<li class="popover-orders">
							<div class="left peity_bar_bad"><span>3,5,9,7,12,20,10</span>-50%</div>
							<div class="right">
								<strong>4808</strong>
								Orders
							</div>
						</li>
						<li class="popover-tickets">
							<div class="left peity_line_good"><span>12,6,9,23,14,10,17</span>+70%</div>
							<div class="right">
								<strong>2968</strong>
								Tickets
							</div>
						</li>
					</ul>
				</div>	
			</div>
			<div class="row-fluid">
				<div class="span12">
					<div class="alert alert-info">
						Welcome in the <strong>Delta Admin Theme</strong>. Comingsoon all the pages!
						<a href="#" data-dismiss="alert" class="close">×</a>
					</div>
					<div class="widget-box">
						<div class="widget-title"><span class="icon"><i class="icon-signal"></i></span><h5>Site Statistics</h5><div class="buttons"><a href="#" class="btn btn-mini"><i class="icon-refresh"></i> Update stats</a></div></div>
						<div class="widget-content">
							<div class="row-fluid">
							<div class="span4">
								<ul class="site-stats">
									<li><i class="icon-spinner icon-spin"></i><strong>0</strong> <small>Pending Orders</small></li>
									<li><i class="icon-user"></i> <strong>106</strong> <small>Total Users</small></li>
									<li><i class="icon-arrow-right"></i> <strong>16</strong> <small>New Users (Today's user)</small></li>
									<li class="divider"></li>
									<li><i class="icon-shopping-cart"></i> <strong>259</strong> <small>Total Menu Items</small></li>
									<li><i class="icon-tag"></i> <strong>4808</strong> <small>Total Orders</small></li>
								</ul>
							</div>
							<div class="span8">
								<div class="chart"></div>
							</div>	
							</div>							
						</div>
					</div>					
				</div>
			</div>
			<div class="row-fluid">
				<div class="span6">
					<div class="widget-box">
						<div class="widget-title"><span class="icon"><i class="icon-file"></i></span><h5>Recent Posts</h5><span title="54 total posts" class="label label-info tip-left">54</span></div>
						<div class="widget-content nopadding">
							<ul class="recent-posts">
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar2.png">
									</div>
									<div class="article-post">
										<span class="user-info"> By: neytiri on 2 Aug 2012, 09:27 AM, IP: 186.56.45.7 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>
									<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
										<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
										<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>	
									</div>
								</li>
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar3.png">
									</div>
									<div class="article-post">
										<span class="user-info"> By: john on on 24 Jun 2012, 04:12 PM, IP: 192.168.24.3 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>
										<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
										<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
										<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>	
									</div>
								</li>
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar1.png">
									</div>
									<div class="article-post">
										<span class="user-info"> By: michelle on 22 Jun 2012, 02:44 PM, IP: 172.10.56.3 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>
										<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
										<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
										<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>
										</div>
								</li>
								<li class="viewall">
									<a title="View all posts" class="tip-top" href="#"> + View all + </a>
								</li>
							</ul>
						</div>
					</div>


					<div class="widget-box">
						<div class="widget-title"><span class="icon"><i class="icon-comment"></i></span><h5>Recent Comments</h5><span title="88 total comments" class="label label-info tip-left">88</span></div>
						<div class="widget-content nopadding">
							<ul class="recent-comments">
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar1.png">
									</div>
									<div class="comments">
										<span class="user-info"> User: michelle on IP: 172.10.56.3 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>
										<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
											<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
											<a class="btn btn-warning btn-mini" href="#" data-placement="top" data-original-title="Make as spam"><i class="icon-trash"></i></a>
											<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>
									</div>
								</li>
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar3.png">
									</div>
									<div class="comments">
										<span class="user-info"> User: john on IP: 192.168.24.3 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>
										<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
											<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
											<a class="btn btn-warning btn-mini" href="#" data-placement="top" data-original-title="Make as spam"><i class="icon-trash"></i></a>
											<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>
									</div>
								</li>
								<li>
									<div class="user-thumb">
										<img width="40" height="40" alt="User" src="themes/images/avatar2.png">
									</div>
									<div class="comments">
										<span class="user-info"> User: neytiri on IP: 186.56.45.7 </span>
										<p>
											<a href="#">Vivamus sed auctor nibh congue, ligula vitae tempus pharetra...</a>
										</p>

											<a class="btn btn-primary btn-mini" href="#" data-placement="right" data-original-title="Edit"><i class="icon-pencil"></i></a>
											<a class="btn btn-success btn-mini" href="#" data-placement="top" data-original-title="Approved"><i class="icon-ok"></i></a>
											<a class="btn btn-warning btn-mini" href="#" data-placement="top" data-original-title="Make as spam"><i class="icon-trash"></i></a>
											<a class="btn btn-danger btn-mini" href="#" data-placement="left" data-original-title="Delete"><i class="icon-remove"></i></a>

									</div>
								</li>
								<li class="viewall">
									<a title="View all comments" class="tip-top" href="#"> + View all + </a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="span6">
					<div class="widget-box widget-calendar">
						<div class="widget-title"><span class="icon"><i class="icon-calendar"></i></span><h5>Calendar</h5></div>
						<div class="widget-content nopadding">
							<div class="calendar"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="row-fluid">
				<div id="footer" class="span12">
					2012 - 2013 &copy; Free Bootstrappage Admin. Brought to you by <a id="poweredBy" href="http://www.bootstrappage.com" target="_blank" title="Free Admin template design and developments"> Free bootstrappage admin template</a>
				</div>
			</div>
		</div>
		</div>

            <script src="themes/js/excanvas.min.js"></script>
            <script src="themes/js/jquery.min.js"></script>
            <script src="themes/js/jquery.ui.custom.js"></script>
            <script src="themes/js/bootstrap.min.js"></script>
            <script src="themes/js/jquery.flot.min.js"></script>
            <script src="themes/js/jquery.flot.resize.min.js"></script>
            <script src="themes/js/jquery.peity.min.js"></script>
            <script src="themes/js/fullcalendar.min.js"></script>
            <script src="themes/js/delta.js"></script>
            <script src="themes/js/delta.dashboard.js"></script>
	</body>
</html>