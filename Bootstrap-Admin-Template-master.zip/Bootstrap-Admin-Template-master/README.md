Free Admin Template with Twitter Bootstrap
------------------------------------------

### Installation

    $ git clone https://github.com/onokumus/Bootstrap-Admin-Template.git yourfoldername
    $ cd yourfoldername
    $ git submodule init
    $ git submodule update

### Demo

[http://demo.onokumus.com/metis/index.html][1]

### Licensing

Bootstrap Admin template is open-sourced software licensed under the [MIT License][2]


  [1]: http://demo.onokumus.com/metis/index.html
  [2]: http://opensource.org/licenses/MIT
